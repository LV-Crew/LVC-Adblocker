# Adblocker
Perhaps the smallest system-wide Adblocker ever!<br>
A Clone of HostsManager from LVC!<br>
(https://github.com/LV-Crew/HostsManager)<br>
(Always latest stable version.)<br>
The latest build of the LVC-Adblocker can be downloaded here: https://github.com/LV-Crew/Adblocker/releases/<br>
<br>
<br>
<h3><b>To-Dos & Ideas:</b></h3>
https://github.com/LV-Crew/Adblocker/wiki//To-Dos-&-Ideas-(Roadmap)<br>
