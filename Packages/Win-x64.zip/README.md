# Adblocker
Adblocker-Clone of HostsManager from LVC<br>
(https://github.com/LV-Crew/HostsManager)<br>
(Always latest stable version.)<br>
<br>
<br>
<h3><b>To-Dos & Ideas:</b></h3>
https://github.com/LV-Crew/Adblocker/wiki//To-Dos-&-Ideas-(Roadmap)<br>
